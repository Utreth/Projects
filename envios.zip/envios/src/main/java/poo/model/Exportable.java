package poo.model;

import org.json.JSONObject;

public interface Exportable {
    
   public JSONObject toJSONObject();

   
    
}
