package poo.model;

public interface Costeable {
    
    public double getCosto();

    public String toJSON();

}
