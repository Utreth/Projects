package poo.helpers;

public class Basura {
    
}
